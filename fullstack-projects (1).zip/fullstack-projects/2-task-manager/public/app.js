const $ = (id) => document.getElementById(id);
const esc = (s = '') => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

let token = localStorage.getItem('tm_token');
let user = JSON.parse(localStorage.getItem('tm_user') || 'null');
let tasks = [];
let filter = 'all';
let mode = 'login';
let socket;

// ---------- API helper ----------
async function api(path, method = 'GET', body) {
  const res = await fetch(path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token && { Authorization: `Bearer ${token}` }) },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && token) logout();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ---------- Auth UI ----------
function setMode(m) {
  mode = m;
  $('tab-login').classList.toggle('active', m === 'login');
  $('tab-register').classList.toggle('active', m === 'register');
  $('name').classList.toggle('hidden', m === 'login');
  $('name').required = m === 'register';
  $('auth-submit').textContent = m === 'login' ? 'Login' : 'Create account';
  $('auth-error').textContent = '';
}
$('tab-login').onclick = () => setMode('login');
$('tab-register').onclick = () => setMode('register');

$('auth-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const body = { email: $('email').value, password: $('password').value };
    if (mode === 'register') body.name = $('name').value;
    const data = await api(`/api/auth/${mode}`, 'POST', body);
    token = data.token;
    user = data.user;
    localStorage.setItem('tm_token', token);
    localStorage.setItem('tm_user', JSON.stringify(user));
    e.target.reset();
    showApp();
  } catch (err) {
    $('auth-error').textContent = err.message;
  }
});

function logout() {
  localStorage.removeItem('tm_token');
  localStorage.removeItem('tm_user');
  token = user = null;
  if (socket) socket.disconnect();
  $('app-view').classList.add('hidden');
  $('auth-view').classList.remove('hidden');
}
$('logout').onclick = logout;

// ---------- Tasks ----------
async function loadTasks() {
  tasks = await api('/api/tasks');
  render();
}

function render() {
  const visible = tasks.filter((t) => filter === 'all' || t.status === filter);
  $('task-list').innerHTML = visible.length
    ? visible.map((t) => `
      <li class="task ${t.priority} ${t.status === 'done' ? 'done' : ''}">
        <div>
          <div class="title">${esc(t.title)}</div>
          <div class="meta">${esc(t.description)} ${t.dueDate ? '· Due ' + new Date(t.dueDate).toLocaleDateString() : ''} · ${t.priority}</div>
        </div>
        <div class="actions">
          <select data-id="${t._id}" class="status">
            ${['todo', 'in-progress', 'done'].map((s) => `<option value="${s}" ${t.status === s ? 'selected' : ''}>${s}</option>`).join('')}
          </select>
          <button data-del="${t._id}">Delete</button>
        </div>
      </li>`).join('')
    : '<li class="empty">No tasks here yet.</li>';
}

$('task-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  await api('/api/tasks', 'POST', {
    title: $('t-title').value,
    description: $('t-desc').value,
    priority: $('t-priority').value,
    dueDate: $('t-due').value || undefined
  });
  e.target.reset();
  loadTasks();
});

$('task-list').addEventListener('change', async (e) => {
  if (e.target.classList.contains('status')) {
    await api(`/api/tasks/${e.target.dataset.id}`, 'PUT', { status: e.target.value });
    loadTasks();
  }
});

$('task-list').addEventListener('click', async (e) => {
  if (e.target.dataset.del) {
    await api(`/api/tasks/${e.target.dataset.del}`, 'DELETE');
    loadTasks();
  }
});

document.querySelectorAll('.filters button').forEach((b) => {
  b.onclick = () => {
    filter = b.dataset.filter;
    document.querySelectorAll('.filters button').forEach((x) => x.classList.toggle('active', x === b));
    render();
  };
});

// ---------- Real-time updates ----------
function connectSocket() {
  socket = io({ auth: { token } });
  socket.on('tasks:changed', loadTasks);
}

function showApp() {
  $('auth-view').classList.add('hidden');
  $('app-view').classList.remove('hidden');
  $('user-name').textContent = user.name;
  connectSocket();
  loadTasks();
}

if (token && user) showApp();
