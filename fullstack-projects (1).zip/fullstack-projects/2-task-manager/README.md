# Project 2: Task Management Application

Create, update and track tasks. JWT authentication, per-user authorization, real-time sync across tabs/devices with Socket.IO, responsive layout.

## Run
```bash
cp .env.example .env
npm install
npm start        # http://localhost:5002
```

## API
| Method | Route | Auth |
|--------|-------|------|
| POST | `/api/auth/register` | - |
| POST | `/api/auth/login` | - |
| GET | `/api/tasks` | Bearer token |
| POST | `/api/tasks` | Bearer token |
| PUT | `/api/tasks/:id` | Bearer token (own tasks only) |
| DELETE | `/api/tasks/:id` | Bearer token (own tasks only) |

Real-time: the server emits `tasks:changed` to the owner's sockets after any create/update/delete, so open tabs refresh instantly.

## Deploy
Deploy to Render/Heroku with env vars `MONGO_URI` and `JWT_SECRET`; start command `npm start`.
