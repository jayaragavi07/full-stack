// If you deploy the frontend separately (Netlify/Vercel), set this to your backend URL.
const API_BASE = '';

document.getElementById('year').textContent = new Date().getFullYear();

const esc = (s = '') => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

async function loadProjects() {
  const list = document.getElementById('project-list');
  try {
    const res = await fetch(`${API_BASE}/api/projects`);
    const projects = await res.json();
    if (!projects.length) { list.innerHTML = '<p>No projects yet.</p>'; return; }
    list.innerHTML = projects.map((p) => `
      <article class="card">
        <h3>${esc(p.title)}</h3>
        <p>${esc(p.description)}</p>
        <div class="tags">${(p.tech || []).map((t) => `<small>${esc(t)}</small>`).join('')}</div>
        ${p.liveUrl ? `<a href="${esc(p.liveUrl)}" target="_blank" rel="noopener">Live</a>` : ''}
        ${p.repoUrl ? `<a href="${esc(p.repoUrl)}" target="_blank" rel="noopener">Code</a>` : ''}
      </article>`).join('');
  } catch {
    list.innerHTML = '<p>Could not load projects.</p>';
  }
}

document.getElementById('contact-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const status = document.getElementById('form-status');
  const body = Object.fromEntries(new FormData(e.target));
  const res = await fetch(`${API_BASE}/api/contact`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  status.textContent = res.ok ? 'Thanks! Your message was sent.' : 'Something went wrong. Please try again.';
  if (res.ok) e.target.reset();
});

loadProjects();
