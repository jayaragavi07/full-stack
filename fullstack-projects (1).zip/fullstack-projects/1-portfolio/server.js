require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const Project = mongoose.model('Project', new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String, required: true },
  tech: [String],
  liveUrl: String,
  repoUrl: String,
  createdAt: { type: Date, default: Date.now }
}));

const Message = mongoose.model('Message', new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  message: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
}));

const adminOnly = (req, res, next) => {
  if (req.get('x-admin-key') !== process.env.ADMIN_KEY) {
    return res.status(401).json({ error: 'Invalid admin key' });
  }
  next();
};

app.get('/api/projects', async (_req, res) => {
  res.json(await Project.find().sort({ createdAt: -1 }));
});

app.post('/api/projects', adminOnly, async (req, res) => {
  try {
    res.status(201).json(await Project.create(req.body));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.delete('/api/projects/:id', adminOnly, async (req, res) => {
  await Project.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

app.post('/api/contact', async (req, res) => {
  try {
    await Message.create(req.body);
    res.status(201).json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: 'Name, email and message are required' });
  }
});

const PORT = process.env.PORT || 5001;
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => app.listen(PORT, () => console.log(`Portfolio running on http://localhost:${PORT}`)))
  .catch((err) => { console.error('MongoDB connection failed:', err.message); process.exit(1); });
