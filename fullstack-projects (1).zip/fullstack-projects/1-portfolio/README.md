# Project 1: Personal Portfolio Website

Full-stack portfolio: static frontend (HTML/CSS/JS) + Node.js/Express API + MongoDB.

## Run
```bash
cp .env.example .env
npm install
npm run seed     # optional sample projects
npm start        # http://localhost:5001
```

## API
| Method | Route | Notes |
|--------|-------|-------|
| GET | `/api/projects` | List projects |
| POST | `/api/projects` | Add project (header `x-admin-key`) |
| DELETE | `/api/projects/:id` | Delete project (header `x-admin-key`) |
| POST | `/api/contact` | Save a contact message |

Add a project:
```bash
curl -X POST http://localhost:5001/api/projects \
  -H "Content-Type: application/json" -H "x-admin-key: change-me" \
  -d '{"title":"My App","description":"What it does","tech":["Node","MongoDB"],"repoUrl":"https://github.com/you/app"}'
```

## Deploy
- **Backend (Render/Heroku):** set `MONGO_URI` (Atlas) and `ADMIN_KEY` env vars, start command `npm start`.
- **Frontend (Netlify/Vercel):** deploy the `public/` folder and set `API_BASE` in `public/script.js` to your backend URL.
- Or deploy everything together on Render/Heroku, since Express already serves `public/`.
