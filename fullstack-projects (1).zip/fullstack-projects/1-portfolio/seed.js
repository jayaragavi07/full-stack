require('dotenv').config();
const mongoose = require('mongoose');

const Project = mongoose.model('Project', new mongoose.Schema({
  title: String, description: String, tech: [String], liveUrl: String, repoUrl: String,
  createdAt: { type: Date, default: Date.now }
}));

const samples = [
  { title: 'Task Management App', description: 'Task manager with JWT auth and real-time updates.', tech: ['Node.js', 'Express', 'MongoDB', 'Socket.IO'], repoUrl: '#' },
  { title: 'E-Commerce Store', description: 'Online store with cart, checkout and order tracking.', tech: ['Node.js', 'Express', 'MongoDB'], repoUrl: '#' },
  { title: 'Blog Platform', description: 'Blog with posts and comments.', tech: ['Node.js', 'Express', 'MongoDB'], repoUrl: '#' }
];

mongoose.connect(process.env.MONGO_URI).then(async () => {
  await Project.deleteMany({});
  await Project.insertMany(samples);
  console.log('Seeded sample projects');
  process.exit(0);
});
