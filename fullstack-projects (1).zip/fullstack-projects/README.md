# Full-Stack Projects

Four full-stack web projects built with **HTML/CSS/JavaScript**, **Node.js + Express**, and **MongoDB (Mongoose)**.

| # | Project | Folder | Highlights |
|---|---------|--------|-----------|
| 1 | Personal Portfolio Website | `1-portfolio` | Projects stored in DB, contact form, admin API, deployable |
| 2 | Task Management Application | `2-task-manager` | JWT auth, task CRUD, real-time updates (Socket.IO), responsive |
| 3 | E-Commerce Web Application | `3-ecommerce` | Product catalog, cart, checkout, orders, Admin/User roles |
| 4 | Blog Platform with Comments | `4-blog-platform` | Register/login, post CRUD, comments, RESTful API |

## Prerequisites
- Node.js 18+
- MongoDB (local, or a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster)

## Run any project
```bash
cd 1-portfolio            # or 2-task-manager, 3-ecommerce, 4-blog-platform
cp .env.example .env      # edit values (MONGO_URI, JWT_SECRET, ...)
npm install
npm start                 # http://localhost:<PORT>
```
Each project has its own `README.md` with ports, API routes and deployment notes.

Default ports: 5001, 5002, 5003, 5004.

## Push to GitHub
```bash
cd fullstack-projects
git init
git add .
git commit -m "Initial commit: four full-stack projects"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
Never commit your `.env` file (it is already in `.gitignore`).
