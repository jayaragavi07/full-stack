require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Models ----------
const User = mongoose.model('User', new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['user', 'admin'], default: 'user' }
}));

const Product = mongoose.model('Product', new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  description: { type: String, default: '' },
  price: { type: Number, required: true, min: 0 },
  stock: { type: Number, default: 0, min: 0 },
  image: { type: String, default: '' },
  category: { type: String, default: 'General' }
}, { timestamps: true }));

const Order = mongoose.model('Order', new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  items: [{
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    name: String,
    price: Number,
    qty: Number
  }],
  total: Number,
  address: { type: String, required: true },
  status: { type: String, enum: ['placed', 'processing', 'shipped', 'delivered', 'cancelled'], default: 'placed' }
}, { timestamps: true }));

// ---------- Auth & roles ----------
const sign = (u) => jwt.sign({ id: u._id, role: u.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
const publicUser = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role });

const auth = (req, res, next) => {
  try {
    const payload = jwt.verify((req.get('authorization') || '').replace('Bearer ', ''), process.env.JWT_SECRET);
    req.userId = payload.id;
    req.role = payload.role;
    next();
  } catch {
    res.status(401).json({ error: 'Please log in' });
  }
};
const adminOnly = (req, res, next) =>
  req.role === 'admin' ? next() : res.status(403).json({ error: 'Admin access required' });

app.post('/api/auth/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password || password.length < 6) {
    return res.status(400).json({ error: 'Name, email and a password of 6+ characters are required' });
  }
  if (await User.findOne({ email: email.toLowerCase() })) return res.status(409).json({ error: 'Email already registered' });
  const user = await User.create({ name, email, password: await bcrypt.hash(password, 10) }); // role always "user"
  res.status(201).json({ token: sign(user), user: publicUser(user) });
});

app.post('/api/auth/login', async (req, res) => {
  const user = await User.findOne({ email: (req.body.email || '').toLowerCase() });
  if (!user || !(await bcrypt.compare(req.body.password || '', user.password))) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  res.json({ token: sign(user), user: publicUser(user) });
});

// ---------- Products ----------
app.get('/api/products', async (req, res) => {
  const filter = req.query.q ? { name: new RegExp(req.query.q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i') } : {};
  res.json(await Product.find(filter).sort({ createdAt: -1 }));
});

app.post('/api/products', auth, adminOnly, async (req, res) => {
  try { res.status(201).json(await Product.create(req.body)); }
  catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/products/:id', auth, adminOnly, async (req, res) => {
  const p = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  p ? res.json(p) : res.status(404).json({ error: 'Product not found' });
});

app.delete('/api/products/:id', auth, adminOnly, async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

// ---------- Orders ----------
// Checkout: prices and stock are always taken from the database, never from the client.
app.post('/api/orders', auth, async (req, res) => {
  try {
    const { items, address } = req.body;
    if (!Array.isArray(items) || !items.length || !address) {
      return res.status(400).json({ error: 'Cart items and delivery address are required' });
    }
    const lines = [];
    let total = 0;
    for (const { productId, qty } of items) {
      const q = parseInt(qty, 10);
      const p = await Product.findById(productId);
      if (!p || !(q > 0)) return res.status(400).json({ error: 'Invalid item in cart' });
      if (p.stock < q) return res.status(400).json({ error: `Only ${p.stock} left of ${p.name}` });
      lines.push({ product: p._id, name: p.name, price: p.price, qty: q });
      total += p.price * q;
    }
    for (const l of lines) await Product.updateOne({ _id: l.product }, { $inc: { stock: -l.qty } });
    const order = await Order.create({ user: req.userId, items: lines, total, address });
    res.status(201).json(order);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get('/api/orders/mine', auth, async (req, res) => {
  res.json(await Order.find({ user: req.userId }).sort({ createdAt: -1 }));
});

app.get('/api/orders', auth, adminOnly, async (_req, res) => {
  res.json(await Order.find().populate('user', 'name email').sort({ createdAt: -1 }));
});

app.put('/api/orders/:id/status', auth, adminOnly, async (req, res) => {
  const order = await Order.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true, runValidators: true });
  order ? res.json(order) : res.status(404).json({ error: 'Order not found' });
});

const PORT = process.env.PORT || 5003;
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => app.listen(PORT, () => console.log(`E-Commerce running on http://localhost:${PORT}`)))
  .catch((err) => { console.error('MongoDB connection failed:', err.message); process.exit(1); });
