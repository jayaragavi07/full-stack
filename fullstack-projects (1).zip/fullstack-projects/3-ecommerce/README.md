# Project 3: E-Commerce Web Application

Basic online store: product catalog, add to cart, checkout, order tracking, JWT login with role-based access (Admin / User).

## Run
```bash
cp .env.example .env
npm install
npm run seed     # sample products + admin account (admin@example.com / admin123)
npm start        # http://localhost:5003
```

## Roles
- **User** (anyone who registers): browse, cart, checkout, view own orders.
- **Admin** (created by `npm run seed`): add/delete products, view all orders, update order status.
Registration can never create an admin; admins are only created via the seed script/database.

## API
| Method | Route | Access |
|--------|-------|--------|
| POST | `/api/auth/register`, `/api/auth/login` | Public |
| GET | `/api/products?q=` | Public |
| POST/PUT/DELETE | `/api/products[/:id]` | Admin |
| POST | `/api/orders` | Logged in (price/stock validated server-side) |
| GET | `/api/orders/mine` | Logged in |
| GET | `/api/orders` | Admin |
| PUT | `/api/orders/:id/status` | Admin |

## Deploy
Render/Heroku with env vars `MONGO_URI` (Atlas) and `JWT_SECRET`. Run the seed script once against the production DB to create the admin (change the default password first!).
