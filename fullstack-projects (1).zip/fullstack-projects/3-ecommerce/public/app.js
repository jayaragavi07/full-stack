const $ = (id) => document.getElementById(id);
const esc = (s = '') => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => '₹' + Number(n).toLocaleString('en-IN');
const ICONS = { Electronics: '🎧', Fashion: '🎒', Home: '🏠', Stationery: '📓', General: '🛍️' };

let token = localStorage.getItem('shop_token');
let user = JSON.parse(localStorage.getItem('shop_user') || 'null');
let cart = JSON.parse(localStorage.getItem('shop_cart') || '[]'); // [{id, name, price, qty}]
let products = [];
let registerMode = false;

async function api(path, method = 'GET', body) {
  const res = await fetch(path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token && { Authorization: `Bearer ${token}` }) },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ---------- Navigation ----------
function show(view) {
  document.querySelectorAll('.view').forEach((v) => v.classList.add('hidden'));
  $('view-' + view).classList.remove('hidden');
  if (view === 'shop') loadProducts();
  if (view === 'cart') renderCart();
  if (view === 'orders') loadMyOrders();
  if (view === 'admin') loadAdmin();
}
document.addEventListener('click', (e) => {
  const link = e.target.closest('[data-view]');
  if (link) { e.preventDefault(); show(link.dataset.view); }
});

function refreshNav() {
  const loggedIn = !!user;
  document.querySelectorAll('.auth-only').forEach((el) => el.classList.toggle('hidden', !loggedIn));
  document.querySelectorAll('.admin-only').forEach((el) => el.classList.toggle('hidden', !(loggedIn && user.role === 'admin')));
  $('login-link').classList.toggle('hidden', loggedIn);
  $('who').textContent = user ? user.name : '';
  $('cart-count').textContent = cart.reduce((n, i) => n + i.qty, 0);
}

// ---------- Auth ----------
$('toggle-auth').onclick = (e) => {
  e.preventDefault();
  registerMode = !registerMode;
  $('auth-title').textContent = registerMode ? 'Register' : 'Login';
  $('a-name').classList.toggle('hidden', !registerMode);
  $('a-name').required = registerMode;
  $('toggle-auth').textContent = registerMode ? 'Have an account? Login' : 'Need an account? Register';
};

$('auth-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const body = { email: $('a-email').value, password: $('a-pass').value };
    if (registerMode) body.name = $('a-name').value;
    const data = await api(`/api/auth/${registerMode ? 'register' : 'login'}`, 'POST', body);
    token = data.token; user = data.user;
    localStorage.setItem('shop_token', token);
    localStorage.setItem('shop_user', JSON.stringify(user));
    e.target.reset();
    refreshNav();
    show('shop');
  } catch (err) {
    $('auth-msg').textContent = err.message;
    $('auth-msg').className = 'msg error';
  }
});

$('logout-link').onclick = (e) => {
  e.preventDefault();
  localStorage.removeItem('shop_token');
  localStorage.removeItem('shop_user');
  token = user = null;
  refreshNav();
  show('shop');
};

// ---------- Catalog ----------
async function loadProducts() {
  products = await api('/api/products?q=' + encodeURIComponent($('search').value));
  $('products').innerHTML = products.length ? products.map((p) => `
    <article class="card product">
      <div class="pic">${ICONS[p.category] || ICONS.General}</div>
      <h4>${esc(p.name)}</h4>
      <p>${esc(p.description)}</p>
      <div class="price">${money(p.price)}</div>
      <div class="stock">${p.stock > 0 ? p.stock + ' in stock' : 'Out of stock'}</div>
      <button class="btn small" data-add="${p._id}" ${p.stock < 1 ? 'disabled' : ''}>Add to cart</button>
    </article>`).join('') : '<p>No products found.</p>';
}
$('search').addEventListener('input', loadProducts);

$('products').addEventListener('click', (e) => {
  const id = e.target.dataset.add;
  if (!id) return;
  const p = products.find((x) => x._id === id);
  const line = cart.find((i) => i.id === id);
  if (line) line.qty = Math.min(line.qty + 1, p.stock);
  else cart.push({ id, name: p.name, price: p.price, qty: 1 });
  saveCart();
});

// ---------- Cart & checkout ----------
function saveCart() {
  localStorage.setItem('shop_cart', JSON.stringify(cart));
  refreshNav();
}

function renderCart() {
  $('cart-msg').textContent = '';
  $('cart-items').innerHTML = cart.length ? cart.map((i) => `
    <div class="row">
      <span>${esc(i.name)} · ${money(i.price)}</span>
      <span>
        <input type="number" min="1" value="${i.qty}" data-qty="${i.id}" />
        <button class="btn small danger" data-remove="${i.id}">Remove</button>
      </span>
    </div>`).join('') : '<p>Your cart is empty.</p>';
  $('checkout').classList.toggle('hidden', !cart.length);
  $('cart-total').textContent = 'Total: ' + money(cart.reduce((n, i) => n + i.price * i.qty, 0));
}

$('cart-items').addEventListener('change', (e) => {
  if (e.target.dataset.qty) {
    const line = cart.find((i) => i.id === e.target.dataset.qty);
    line.qty = Math.max(1, parseInt(e.target.value, 10) || 1);
    saveCart(); renderCart();
  }
});
$('cart-items').addEventListener('click', (e) => {
  if (e.target.dataset.remove) {
    cart = cart.filter((i) => i.id !== e.target.dataset.remove);
    saveCart(); renderCart();
  }
});

$('place-order').onclick = async () => {
  const msg = $('cart-msg');
  if (!user) { msg.textContent = 'Please log in to check out.'; msg.className = 'msg error'; return show('login'); }
  try {
    await api('/api/orders', 'POST', {
      items: cart.map((i) => ({ productId: i.id, qty: i.qty })),
      address: $('address').value
    });
    cart = []; saveCart(); $('address').value = '';
    renderCart();
    $('cart-msg').textContent = 'Order placed! Track it under My Orders.';
    $('cart-msg').className = 'msg ok';
  } catch (err) {
    msg.textContent = err.message; msg.className = 'msg error';
  }
};

// ---------- Orders ----------
const orderRow = (o, admin) => `
  <div class="row">
    <div>
      <strong>#${o._id.slice(-6)}</strong> · ${new Date(o.createdAt).toLocaleDateString()}
      ${admin ? ` · ${esc(o.user?.name || '')}` : ''}<br>
      <small>${o.items.map((i) => `${esc(i.name)} × ${i.qty}`).join(', ')}</small><br>
      <small>${esc(o.address)}</small>
    </div>
    <div>
      <strong>${money(o.total)}</strong>
      ${admin
        ? `<select data-status="${o._id}">${['placed', 'processing', 'shipped', 'delivered', 'cancelled'].map((s) => `<option ${o.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select>`
        : `<span class="badge">${o.status}</span>`}
    </div>
  </div>`;

async function loadMyOrders() {
  const orders = await api('/api/orders/mine');
  $('my-orders').innerHTML = orders.length ? orders.map((o) => orderRow(o, false)).join('') : '<p>No orders yet.</p>';
}

// ---------- Admin ----------
async function loadAdmin() {
  const [prods, orders] = await Promise.all([api('/api/products'), api('/api/orders')]);
  $('admin-products').innerHTML = prods.map((p) => `
    <div class="row">
      <span>${esc(p.name)} · ${money(p.price)} · stock ${p.stock}</span>
      <button class="btn small danger" data-delprod="${p._id}">Delete</button>
    </div>`).join('');
  $('admin-orders').innerHTML = orders.length ? orders.map((o) => orderRow(o, true)).join('') : '<p>No orders yet.</p>';
}

$('product-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  await api('/api/products', 'POST', {
    name: $('p-name').value, description: $('p-desc').value,
    price: Number($('p-price').value), stock: Number($('p-stock').value),
    category: $('p-cat').value || 'General'
  });
  e.target.reset();
  loadAdmin();
});

$('view-admin').addEventListener('click', async (e) => {
  if (e.target.dataset.delprod && confirm('Delete this product?')) {
    await api(`/api/products/${e.target.dataset.delprod}`, 'DELETE');
    loadAdmin();
  }
});
$('view-admin').addEventListener('change', async (e) => {
  if (e.target.dataset.status) {
    await api(`/api/orders/${e.target.dataset.status}/status`, 'PUT', { status: e.target.value });
  }
});

refreshNav();
show('shop');
