require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const User = mongoose.model('User', new mongoose.Schema({
  name: String, email: { type: String, unique: true }, password: String, role: String
}));
const Product = mongoose.model('Product', new mongoose.Schema({
  name: String, description: String, price: Number, stock: Number, image: String, category: String
}, { timestamps: true }));

const products = [
  { name: 'Wireless Headphones', description: 'Over-ear Bluetooth headphones with 30h battery.', price: 2499, stock: 25, category: 'Electronics' },
  { name: 'Mechanical Keyboard', description: 'Compact RGB keyboard with tactile switches.', price: 3299, stock: 15, category: 'Electronics' },
  { name: 'Backpack', description: 'Water-resistant 25L laptop backpack.', price: 1499, stock: 40, category: 'Fashion' },
  { name: 'Water Bottle', description: 'Insulated stainless steel bottle, 750ml.', price: 599, stock: 60, category: 'Home' },
  { name: 'Notebook Set', description: 'Pack of 3 ruled notebooks.', price: 249, stock: 100, category: 'Stationery' },
  { name: 'Desk Lamp', description: 'LED lamp with adjustable brightness.', price: 899, stock: 30, category: 'Home' }
];

mongoose.connect(process.env.MONGO_URI).then(async () => {
  await Product.deleteMany({});
  await Product.insertMany(products);
  const email = (process.env.ADMIN_EMAIL || 'admin@example.com').toLowerCase();
  await User.deleteOne({ email });
  await User.create({ name: 'Admin', email, password: await bcrypt.hash(process.env.ADMIN_PASSWORD || 'admin123', 10), role: 'admin' });
  console.log(`Seeded ${products.length} products and admin user ${email}`);
  process.exit(0);
});
