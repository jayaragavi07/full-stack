const $ = (id) => document.getElementById(id);
const esc = (s = '') => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (d) => new Date(d).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });

let token = localStorage.getItem('blog_token');
let user = JSON.parse(localStorage.getItem('blog_user') || 'null');
let currentPost = null;
let editingId = null;
let registerMode = false;

async function api(path, method = 'GET', body) {
  const res = await fetch(path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token && { Authorization: `Bearer ${token}` }) },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ---------- Navigation ----------
function show(view) {
  document.querySelectorAll('.view').forEach((v) => v.classList.add('hidden'));
  $('view-' + view).classList.remove('hidden');
  if (view === 'list') loadPosts();
  if (view === 'editor' && !editingId) {
    $('editor-title').textContent = 'New post';
    $('post-form').reset();
  }
}
document.addEventListener('click', (e) => {
  const link = e.target.closest('[data-view]');
  if (link) {
    e.preventDefault();
    if (link.dataset.view === 'editor') editingId = null;
    show(link.dataset.view);
  }
});

function refreshNav() {
  document.querySelectorAll('.auth-only').forEach((el) => el.classList.toggle('hidden', !user));
  $('login-link').classList.toggle('hidden', !!user);
  $('who').textContent = user ? user.name : '';
}

// ---------- Auth ----------
$('toggle-auth').onclick = (e) => {
  e.preventDefault();
  registerMode = !registerMode;
  $('auth-title').textContent = registerMode ? 'Register' : 'Login';
  $('a-name').classList.toggle('hidden', !registerMode);
  $('a-name').required = registerMode;
  $('toggle-auth').textContent = registerMode ? 'Have an account? Login' : 'Need an account? Register';
};

$('auth-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const body = { email: $('a-email').value, password: $('a-pass').value };
    if (registerMode) body.name = $('a-name').value;
    const data = await api(`/api/auth/${registerMode ? 'register' : 'login'}`, 'POST', body);
    token = data.token; user = data.user;
    localStorage.setItem('blog_token', token);
    localStorage.setItem('blog_user', JSON.stringify(user));
    e.target.reset();
    refreshNav();
    show('list');
  } catch (err) {
    $('auth-msg').textContent = err.message;
    $('auth-msg').className = 'msg error';
  }
});

$('logout-link').onclick = (e) => {
  e.preventDefault();
  localStorage.removeItem('blog_token');
  localStorage.removeItem('blog_user');
  token = user = null;
  refreshNav();
  show('list');
};

// ---------- Posts ----------
async function loadPosts() {
  const posts = await api('/api/posts');
  $('posts').innerHTML = posts.length ? posts.map((p) => `
    <article class="post-card">
      <h2 data-open="${p._id}">${esc(p.title)}</h2>
      <div class="meta">by ${esc(p.author?.name || 'Unknown')} · ${fmt(p.createdAt)}</div>
      <p class="excerpt">${esc(p.content.slice(0, 180))}${p.content.length > 180 ? '…' : ''}</p>
    </article>`).join('') : '<p class="muted">No posts yet. Log in and write the first one!</p>';
}

$('posts').addEventListener('click', (e) => {
  if (e.target.dataset.open) openPost(e.target.dataset.open);
});

async function openPost(id) {
  currentPost = await api(`/api/posts/${id}`);
  const mine = user && currentPost.author && currentPost.author._id === user.id;
  $('post-detail').innerHTML = `
    <h1>${esc(currentPost.title)}</h1>
    <div class="meta">by ${esc(currentPost.author?.name || 'Unknown')} · ${fmt(currentPost.createdAt)}</div>
    <div class="body">${esc(currentPost.content)}</div>
    ${mine ? `<button class="btn small" id="edit-post">Edit</button> <button class="btn small danger" id="delete-post">Delete</button>` : ''}`;
  show('post');
  $('comment-form').classList.toggle('hidden', !user);
  $('comment-login').classList.toggle('hidden', !!user);
  loadComments();
}

$('post-detail').addEventListener('click', async (e) => {
  if (e.target.id === 'edit-post') {
    editingId = currentPost._id;
    $('editor-title').textContent = 'Edit post';
    $('post-title').value = currentPost.title;
    $('post-content').value = currentPost.content;
    show('editor');
  }
  if (e.target.id === 'delete-post' && confirm('Delete this post and its comments?')) {
    await api(`/api/posts/${currentPost._id}`, 'DELETE');
    show('list');
  }
});

$('post-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = { title: $('post-title').value, content: $('post-content').value };
  try {
    const post = editingId
      ? await api(`/api/posts/${editingId}`, 'PUT', body)
      : await api('/api/posts', 'POST', body);
    editingId = null;
    openPost(post._id);
  } catch (err) {
    $('post-msg').textContent = err.message;
    $('post-msg').className = 'msg error';
  }
});

// ---------- Comments ----------
async function loadComments() {
  const comments = await api(`/api/posts/${currentPost._id}/comments`);
  $('comments').innerHTML = comments.length ? comments.map((c) => `
    <div class="comment">
      <div class="meta"><span>${esc(c.author?.name || 'Unknown')} · ${fmt(c.createdAt)}</span>
        ${user && c.author && c.author._id === user.id ? `<button class="btn small danger" data-delc="${c._id}">Delete</button>` : ''}
      </div>
      <p>${esc(c.text)}</p>
    </div>`).join('') : '<p class="muted">No comments yet.</p>';
}

$('comment-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  await api(`/api/posts/${currentPost._id}/comments`, 'POST', { text: $('comment-text').value });
  e.target.reset();
  loadComments();
});

$('comments').addEventListener('click', async (e) => {
  if (e.target.dataset.delc) {
    await api(`/api/comments/${e.target.dataset.delc}`, 'DELETE');
    loadComments();
  }
});

refreshNav();
show('list');
