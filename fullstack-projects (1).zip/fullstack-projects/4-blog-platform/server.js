require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Models ----------
const User = mongoose.model('User', new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true }
}));

const Post = mongoose.model('Post', new mongoose.Schema({
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true, trim: true },
  content: { type: String, required: true }
}, { timestamps: true }));

const Comment = mongoose.model('Comment', new mongoose.Schema({
  post: { type: mongoose.Schema.Types.ObjectId, ref: 'Post', required: true },
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  text: { type: String, required: true, trim: true }
}, { timestamps: true }));

// ---------- Auth ----------
const sign = (u) => jwt.sign({ id: u._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
const publicUser = (u) => ({ id: u._id, name: u.name, email: u.email });

const auth = (req, res, next) => {
  try {
    req.userId = jwt.verify((req.get('authorization') || '').replace('Bearer ', ''), process.env.JWT_SECRET).id;
    next();
  } catch {
    res.status(401).json({ error: 'Please log in' });
  }
};

app.post('/api/auth/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password || password.length < 6) {
    return res.status(400).json({ error: 'Name, email and a password of 6+ characters are required' });
  }
  if (await User.findOne({ email: email.toLowerCase() })) return res.status(409).json({ error: 'Email already registered' });
  const user = await User.create({ name, email, password: await bcrypt.hash(password, 10) });
  res.status(201).json({ token: sign(user), user: publicUser(user) });
});

app.post('/api/auth/login', async (req, res) => {
  const user = await User.findOne({ email: (req.body.email || '').toLowerCase() });
  if (!user || !(await bcrypt.compare(req.body.password || '', user.password))) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  res.json({ token: sign(user), user: publicUser(user) });
});

// ---------- Posts (CRUD) ----------
app.get('/api/posts', async (_req, res) => {
  res.json(await Post.find().populate('author', 'name').sort({ createdAt: -1 }));
});

app.get('/api/posts/:id', async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ error: 'Post not found' });
  const post = await Post.findById(req.params.id).populate('author', 'name');
  post ? res.json(post) : res.status(404).json({ error: 'Post not found' });
});

app.post('/api/posts', auth, async (req, res) => {
  try {
    const { title, content } = req.body;
    res.status(201).json(await Post.create({ title, content, author: req.userId }));
  } catch (e) {
    res.status(400).json({ error: 'Title and content are required' });
  }
});

app.put('/api/posts/:id', auth, async (req, res) => {
  const { title, content } = req.body;
  const post = await Post.findOneAndUpdate(
    { _id: req.params.id, author: req.userId }, // only the author can edit
    { title, content },
    { new: true, runValidators: true, omitUndefined: true }
  );
  post ? res.json(post) : res.status(404).json({ error: 'Post not found or not yours' });
});

app.delete('/api/posts/:id', auth, async (req, res) => {
  const post = await Post.findOneAndDelete({ _id: req.params.id, author: req.userId });
  if (!post) return res.status(404).json({ error: 'Post not found or not yours' });
  await Comment.deleteMany({ post: post._id });
  res.json({ ok: true });
});

// ---------- Comments ----------
app.get('/api/posts/:id/comments', async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.json([]);
  res.json(await Comment.find({ post: req.params.id }).populate('author', 'name').sort({ createdAt: 1 }));
});

app.post('/api/posts/:id/comments', auth, async (req, res) => {
  try {
    if (!(await Post.exists({ _id: req.params.id }))) return res.status(404).json({ error: 'Post not found' });
    res.status(201).json(await Comment.create({ post: req.params.id, author: req.userId, text: req.body.text }));
  } catch (e) {
    res.status(400).json({ error: 'Comment text is required' });
  }
});

app.delete('/api/comments/:id', auth, async (req, res) => {
  const c = await Comment.findOneAndDelete({ _id: req.params.id, author: req.userId });
  c ? res.json({ ok: true }) : res.status(404).json({ error: 'Comment not found or not yours' });
});

const PORT = process.env.PORT || 5004;
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => app.listen(PORT, () => console.log(`Blog running on http://localhost:${PORT}`)))
  .catch((err) => { console.error('MongoDB connection failed:', err.message); process.exit(1); });
