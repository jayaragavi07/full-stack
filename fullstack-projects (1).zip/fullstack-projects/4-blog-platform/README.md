# Project 4: Blog Platform with Comments

Users register/login, create/edit/delete their own posts, and comment on any post. RESTful API with MongoDB.

## Run
```bash
cp .env.example .env
npm install
npm start        # http://localhost:5004
```

## API
| Method | Route | Access |
|--------|-------|--------|
| POST | `/api/auth/register`, `/api/auth/login` | Public |
| GET | `/api/posts`, `/api/posts/:id` | Public |
| POST | `/api/posts` | Logged in |
| PUT/DELETE | `/api/posts/:id` | Post author only |
| GET | `/api/posts/:id/comments` | Public |
| POST | `/api/posts/:id/comments` | Logged in |
| DELETE | `/api/comments/:id` | Comment author only |

## Deploy
Render/Heroku with env vars `MONGO_URI` (Atlas) and `JWT_SECRET`; start command `npm start`.
